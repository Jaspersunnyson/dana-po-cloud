#!/usr/bin/env bash
# Import the n8n workflow defined in this repository using the n8n CLI.

# This script assumes you have n8n installed globally or available in your
# PATH within the container. It imports the workflow file located in
# `n8n/workflow.json` into your running n8n instance. Adjust the
# `--credentials` option as needed if you need to import credentials.

set -euo pipefail

WORKFLOW_FILE="$(dirname "$0")/workflow.json"

if [ ! -f "$WORKFLOW_FILE" ]; then
    echo "Workflow file not found at $WORKFLOW_FILE" >&2
    exit 1
fi

echo "Importing n8n workflow from $WORKFLOW_FILE..."
n8n import:workflow --input "$WORKFLOW_FILE"
echo "Workflow import completed."